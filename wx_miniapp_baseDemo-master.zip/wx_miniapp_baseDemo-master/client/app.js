//app.js
App({
    config: {
        host: 'wuxing.9z9z.vip'
    },
    onLaunch () {
        console.log('App.onLaunch()');
    }
});