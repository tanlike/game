## 微信小程序自定义服务器部署demo

client: 小程序代码,微信开发者工具中打开

server: 小程序基于nodejs后台服务器代码, 需要部署到https的服务器上运行

相关教程见博客

*久而久之*

[博客园](http://www.cnblogs.com/acharless)

[简书](http://www.jianshu.com/u/43bc4283df00)
